import slide1 from "./Audley_public_house.webp";
import slide2 from "./Cittie_of_Dorke.webp";
import slide3 from "./The_Churchill_arms.webp";
import slide4 from "./The_jack_horner.webp";

export { slide1, slide2, slide3, slide4 };
