import slide1mobile from "./Audley_public_house.webp";
import slide2mobile from "./Cittie_of_Dorke.webp";
import slide3mobile from "./The_Churchill_arms.webp";
import slide4mobile from "./The_jack_horner.webp";

export { slide1mobile, slide2mobile, slide3mobile, slide4mobile };
