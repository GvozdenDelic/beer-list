import slide1tablet from "./Audley_public_house.webp";
import slide2tablet from "./Cittie_of_Dorke.webp";
import slide3tablet from "./The_Churchill_arms.webp";
import slide4tablet from "./The_jack_horner.webp";

export { slide1tablet, slide2tablet, slide3tablet, slide4tablet };
